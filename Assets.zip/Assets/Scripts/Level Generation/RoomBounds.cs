using UnityEngine;

public class RoomBounds : MonoBehaviour
{
    public enum BoundsType
    {
        Inner, Outer
    }

    public RoomBounds.BoundsType type;

    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
