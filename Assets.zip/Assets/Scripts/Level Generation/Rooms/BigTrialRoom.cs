using UnityEngine;

public class BigTrialRoom : TrialRoom
{
}
