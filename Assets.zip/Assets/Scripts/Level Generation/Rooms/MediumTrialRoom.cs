using UnityEngine;

public class MediumTrialRoom : TrialRoom
{
}
