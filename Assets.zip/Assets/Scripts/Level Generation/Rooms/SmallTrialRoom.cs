using UnityEngine;

public class SmallTrialRoom : TrialRoom
{
}
